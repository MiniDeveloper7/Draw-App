extends Node

# The base variables
var image:Image
var tex:ImageTexture

# Mouse variable
var mouse_pos:Vector2

# Corners variables
var top_left:Vector2
var bottom_right:Vector2

var top_right:Vector2
var bottom_left:Vector2

# Color cache
var color_cache:Dictionary = {}

# Sprite size
var sprite_size:Vector2i

# File travel
var is_openning:bool = false
var file_path:String

# Language
var change_language:bool = false
