extends Resource
class_name CanvasManager

# ------ Base Variables ------

var grid_place:Control
var sprite:Sprite2D

# ------ Grid Functions ------
var canvas_rect:Rect2

# Make the grid, for....visualizing!
func DrawGrid():
	# calculates the values
	var img_size = SharedVariables.image.get_size()
	var cell_size = canvas_rect.size / Vector2(img_size)

	# --- height section ---
	for i in range(img_size.x + 1):
		var x_pos = canvas_rect.position.x + (i * cell_size.x)
		grid_place.draw_line(
			Vector2(x_pos, canvas_rect.position.y),
			Vector2(x_pos, canvas_rect.end.y),
			Color.BLUE,
			1.0
		)
	
	# --- width section ---
	for i in range(img_size.y + 1):
		var y_pos = canvas_rect.position.y + (i * cell_size.y)
		grid_place.draw_line(
			Vector2(canvas_rect.position.x, y_pos),
			Vector2(canvas_rect.end.x, y_pos),
			Color.RED,
			1.0
		)

# Draw connetor
func DrawConnector() -> void:
	DrawGrid() # Grids...

	# Draws the border using (rect2)
	grid_place.draw_rect(canvas_rect, Color.WHITE, false, 2.0)

# ------ Updating Function ------

# Updating the corner
func UpdateCalculate():
	# Doing some formulas... -_-
	var size = sprite.texture.get_size() * sprite.scale
	var pos = sprite.global_position - (size / 2.0)
	canvas_rect = Rect2(pos, size)
	
	# Setting the values
	SharedVariables.top_left = canvas_rect.position
	SharedVariables.bottom_right = canvas_rect.end

func UpdateTexture(image: Image):
	SharedVariables.image = image
	SharedVariables.tex = ImageTexture.create_from_image(image)
	sprite.texture = SharedVariables.tex
	
	UpdateCalculate()

# ------ Moving Function ------

# Moves canvas
func MovingCanvas(layout_func: Callable):
	var get_directions:Vector2 = Input.get_vector(&'ui_left', &'ui_right', &'ui_up', &'ui_down').normalized()
	if get_directions:
		sprite.global_position += get_directions * 5
		
		layout_func.call()
