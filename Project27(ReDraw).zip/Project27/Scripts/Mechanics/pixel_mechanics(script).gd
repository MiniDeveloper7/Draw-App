extends Resource
class_name PixelMechanics

var point_on_pixel:Vector2i

var total_size:Vector2
var x_cell_size:Vector2

# Initialise variables
func MakeVariables():
	total_size = SharedVariables.bottom_right - SharedVariables.top_left
	x_cell_size = total_size / SharedVariables.sprite_size.x

# Pixel checker and changer
func PixelCheck(ColorMech: ColorMechanics):
	# Getting some variables
	var local_mouse_pos = SharedVariables.mouse_pos - SharedVariables.top_left
	var grid_pos:Vector2i = ((local_mouse_pos / x_cell_size).floor())
	
	# Checking if the mouse on the picture
	if grid_pos.x >= 0 and grid_pos.x < SharedVariables.sprite_size.x and\
	grid_pos.y >= 0 and grid_pos.y < SharedVariables.sprite_size.y:
		# If mouse has point on new pixel, then make these two functions (coloring and returning old pixel to his old color)
		if grid_pos != point_on_pixel:
			ColorMech.ReturnOldPixel(point_on_pixel, SharedVariables.tex, SharedVariables.image)
			ColorMech.HighlightPixel(grid_pos, SharedVariables.tex, SharedVariables.image)

			point_on_pixel = grid_pos
	else:
		# If the mouse isn't pointing on pixel
		if point_on_pixel != Vector2i.ONE * -1:
			ColorMech.ReturnOldPixel(Vector2i(point_on_pixel), SharedVariables.tex, SharedVariables.image)
			
			point_on_pixel = Vector2.ONE * -1
