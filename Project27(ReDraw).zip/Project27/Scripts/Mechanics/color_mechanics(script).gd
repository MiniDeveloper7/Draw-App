extends Resource
class_name ColorMechanics

var selected_color:Color

# Change a color pixel
func ColorPixel(pixel: Vector2i, color_picker: ColorPicker):
	if (SharedVariables.color_cache.is_empty()) or (pixel not in SharedVariables.color_cache): return # Guard!

	SharedVariables.color_cache[pixel] = color_picker.color

# Highlitghting pixel
func HighlightPixel(pixels: Vector2i, tex: Texture, image: Image):
	# Save spot
	if pixels not in SharedVariables.color_cache:
		SharedVariables.color_cache[pixels] = image.get_pixel(pixels.x, pixels.y)
	
	# Change the selected pixel
	image.set_pixel(pixels.x, pixels.y, selected_color); tex.update(image)

# Getting back the old one
func ReturnOldPixel(pixels: Vector2i, tex: Texture, image: Image):
	if (SharedVariables.color_cache.is_empty()): return # Checking if the cache was empty, so avoiding the errors buddy!
	
	# Checking the "dictionary", if has the value, or not!
	if pixels in SharedVariables.color_cache:
		image.set_pixel(pixels.x, pixels.y, SharedVariables.color_cache[pixels]); tex.update(image)

# Color all pixels
func ColorAllPixel(pixel: Vector2i, tex: Texture, image: Image):
	if (SharedVariables.color_cache.is_empty()) or (pixel not in SharedVariables.color_cache): return # Guard!

	var vector_cache:Dictionary = {} # Make new Dictionary

	# Looping for each pixel!
	for y in range(SharedVariables.sprite_size.y):
		for x in range(SharedVariables.sprite_size.x):
			vector_cache[Vector2i(x, y)] = selected_color # And changing the color
			image.set_pixel(x, y, selected_color)
	
	# Coping the Dic and put it in the cache!
	SharedVariables.color_cache = vector_cache.duplicate(true)
	tex.update(image)

func ErasePixel(pixel: Vector2i, tex: Texture, image: Image):
	if (SharedVariables.color_cache.is_empty()): return # Checking

	# Checking if the pixel was in the cache!
	if pixel in SharedVariables.color_cache:
		# This is makes the pixel color NOTHING
		SharedVariables.color_cache[pixel] = Color(0, 0, 0, 0)
		image.set_pixel(pixel.x, pixel.y, Color(0, 0, 0, 0)); tex.update(image) # Updating as well!
