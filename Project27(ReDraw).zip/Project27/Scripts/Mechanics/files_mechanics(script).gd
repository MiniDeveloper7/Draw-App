extends Resource
class_name FileMechanics

var save_type:int = 0

# ------ Save/Export Functions ------

# Saving
func SaveFile(path: String, pixels_values: Dictionary):
	if save_type != 1: return # Guard

	# Stores the saves
	var converted = JSON.stringify(
		['Draw App File', SharedVariables.sprite_size, pixels_values]
		, '\t'
	)

	# Making the file
	var make_file = FileAccess.open(path, FileAccess.WRITE)

	if make_file:
		make_file.store_line(converted) # Putting the file
		make_file.close() # Close it (Guard)

# Uhhh...Exporting, from what i think?
func ExportImage(path: String):
	if save_type != 3: return # Guard

	SharedVariables.image.save_png(path)

# ------ Open Functions ------

# Openning
func OpenFile(path: String, update_tex: Callable):
	if save_type != 2: return # Guard
	
	# Save reading
	var data = QuickOpen(path)

	# Draw file requirements
	if not IsFileValid(data): return

	# Getting width/height
	var sprite_vector:Vector2i = str_to_var('Vector2i' + data[1])

	# Checks if the (Stores Color Number) = (Canvas)
	if (data[2] as Dictionary).size() == (sprite_vector.x * sprite_vector.y):
		var new_dic:Dictionary = ConvertToVar(data[2])
		var updated_image:Image = LoadImage(new_dic, sprite_vector.x) # Loading image (Drawing new image)

		SharedVariables.sprite_size = sprite_vector # Setting the sprite size...
		SharedVariables.color_cache = new_dic.duplicate(true) # copying the dictionary

		update_tex.call(updated_image) # Updating it

# Better save reading
func QuickOpen(path: String):
	if not FileAccess.file_exists(path): return null
	
	var content = FileAccess.get_file_as_string(path)
	
	var json = JSON.new()
	var error = json.parse(content)
	
	if error != OK: return null
	
	return json.data

# File requirements
func IsFileValid(data):
	return data is Array and \
		   data.size() == 3 and \
		   data[0] == 'Draw App File'

# Loads an image
func LoadImage(cache: Dictionary, image_size: int) -> Image:
	var new_image:Image = Image.create(image_size, image_size, true, Image.FORMAT_RGBA8)

	for y in range(image_size):
		for x in range(image_size):
			# Setting the color on the image
			new_image.set_pixel(x, y, cache[Vector2i(x, y)])
	return new_image

# Converted dictionary
func ConvertToVar(storage: Dictionary) -> Dictionary:
	var perfect_storage = {}

	for key in storage.keys():
		var get_value:String = storage[key]
		var real_key:Vector2i = str_to_var('Vector2i' + key)

		perfect_storage[real_key] = str_to_var('Color' + get_value)
	return perfect_storage
