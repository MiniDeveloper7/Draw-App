extends CanvasLayer

enum Tools {
	None,
	Draw,
	Bucket,
	Eraser,
}

@onready var draw_place: Control = $DrawPlace
@onready var color_place: Control = $ColorPickPlace
@onready var grid_place: Control = $GridPlace
@onready var tools_place: Control = $ToolsPlace
@onready var window_place: Control = $WindowPlace
@onready var centered_grid: PanelContainer = $GridPlace/CenterGrid
@onready var sprite: Sprite2D = $DrawPlace/CenteredObjects/Sprite
@onready var color_picker: ColorPicker = $ColorPickPlace/ColorPicker
@onready var draw_button: TextureButton = $ToolsPlace/Panel/HBox/DrawButton
@onready var bucket_button: TextureButton = $ToolsPlace/Panel/HBox/BucketButton
@onready var erase_button: TextureButton = $ToolsPlace/Panel/HBox/EraseButton
@onready var menu_button: MenuButton = $ToolsPlace/Panel/HBox/MenuButton
@onready var file_dialog: FileDialog = $WindowPlace/FileDialog

@export_group('Resources')
@export var CanvasMana:CanvasManager
@export var PixelMech:PixelMechanics
@export var ColorMech:ColorMechanics
@export var FileMech:FileMechanics
@export_group('Variables')
@export var main_menu: String

var what_tool:Tools = Tools.None

var what_pixel:Vector2i

var is_draw_pixel:bool = true
var is_color_picker_opened:bool = false

# ------ Sub Functions ------

# - Tools Control -

# Checks the position of the art
func PixelsDetection():
	if is_draw_pixel:
		PixelMech.PixelCheck(ColorMech)

# Open the "ColorPicker Tab", and yeah...pick
func OpenColorPicker():
	if !is_color_picker_opened and !file_dialog.visible: PencilSwitches(false)
	else: PencilSwitches(true)

func PencilSwitches(switch: bool):
	is_draw_pixel = switch; grid_place.visible = switch
	color_place.visible = !switch; is_color_picker_opened = !switch

# - Buttons Signal -

# Bucket pressed tools
func PressedTools(what: Tools):
	what_tool = what

# - File Control And Signal -

# Drop down menu
func DropDownMenu(menu_id: int):
	match menu_id:
		1, 2, 3: HandleTypes(menu_id)
		5: get_tree().change_scene_to_file(main_menu)

# File Handler
func HandleTypes(index: int):
	match index:
		1:
			file_dialog.filters = ['*.json ; JSON File']
			file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
		2:
			file_dialog.filters = ['*.json ; JSON File']
			file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		3:
			file_dialog.filters = ['*.png ; PNG Image']
			file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	
	FileMech.save_type = index
	is_draw_pixel = false; file_dialog.popup_centered()

# - Gather All Color -

# Prepare all pixels colors
func PreparePixelColor():
	for y_axis in range(SharedVariables.image.get_height()):
		for x_axis in range(SharedVariables.image.get_width()):
			SharedVariables.color_cache[Vector2i(x_axis, y_axis)] = SharedVariables.image.get_pixel(x_axis, y_axis)

# - Layout -

# Calculates for layout
func Layout():
	CanvasMana.UpdateCalculate() # Invokes the calculator
	PixelMech.MakeVariables() # Updating variables -_-

	grid_place.queue_redraw()

# Apply zoom
func ApplyZoom(amount: float):
	var change_scale = clamp(sprite.scale.x + amount, 1, 75)
	sprite.scale = Vector2(change_scale, change_scale)

	Layout()

# ------ Receives Functions ------

# Receive Open
func ReceiveOpen():
	if SharedVariables.is_openning:
		SharedVariables.is_openning = false

		FileMech.save_type = 2
		FileMech.OpenFile(
			SharedVariables.file_path,
			CanvasMana.UpdateTexture
		)

# Received Language
func ReceiveLanguage():
	if SharedVariables.change_language:
		menu_button.text = 'ملف'
		menu_button.get_popup().set_item_text(0, 'ملف')
		menu_button.get_popup().set_item_text(1, 'حفظ')
		menu_button.get_popup().set_item_text(2, 'فتح')
		menu_button.get_popup().set_item_text(3, 'تصدير')
		menu_button.get_popup().set_item_text(4, 'أوامر')
		menu_button.get_popup().set_item_text(5, 'رجوع للقائمه السابقه')

		draw_place.layout_direction = Control.LAYOUT_DIRECTION_RTL
		color_place.layout_direction = Control.LAYOUT_DIRECTION_RTL
		grid_place.layout_direction = Control.LAYOUT_DIRECTION_RTL
		tools_place.layout_direction = Control.LAYOUT_DIRECTION_RTL
		window_place.layout_direction = Control.LAYOUT_DIRECTION_RTL

		file_dialog.cancel_button_text = 'اغلاق'
		file_dialog.ok_button_text = 'حفظ'
	else:
		menu_button.text = 'File'
		menu_button.get_popup().set_item_text(0, 'File')
		menu_button.get_popup().set_item_text(1, 'Save')
		menu_button.get_popup().set_item_text(2, 'Open')
		menu_button.get_popup().set_item_text(3, 'Export')
		menu_button.get_popup().set_item_text(4, 'Action')
		menu_button.get_popup().set_item_text(5, 'Go Back')

		draw_place.layout_direction = Control.LAYOUT_DIRECTION_LTR
		color_place.layout_direction = Control.LAYOUT_DIRECTION_LTR
		grid_place.layout_direction = Control.LAYOUT_DIRECTION_LTR
		tools_place.layout_direction = Control.LAYOUT_DIRECTION_LTR
		window_place.layout_direction = Control.LAYOUT_DIRECTION_LTR

		file_dialog.cancel_button_text = 'Cancel'
		file_dialog.ok_button_text = 'Save'

# ------ Initiate Functions ------

# Set up the image!!!! :)
func InitiateImage():
	# Coloring the pixel
	for i in range(SharedVariables.sprite_size.y):
		for v in range(SharedVariables.sprite_size.x):
			if v % 2: SharedVariables.image.set_pixel(v, i, Color.BLACK)
			else: SharedVariables.image.set_pixel(v, i, Color.GRAY)

	# Updates and set the "image"
	SharedVariables.tex = ImageTexture.create_from_image(SharedVariables.image)
	sprite.texture = SharedVariables.tex

	sprite.scale = Vector2.ONE * 50 # Scale it!
	PreparePixelColor() # And stores all pixels...

# Set up the "Connection"
func InitiateConnections():
	# Connects the function to "draw"
	grid_place.draw.connect(
		func ConnectBothFunctions():
			CanvasMana.DrawConnector() # Draw the grids
	)

	# Connects buttons
	draw_button.pressed.connect(  PressedTools.bind(Tools.Draw  ))
	bucket_button.pressed.connect(PressedTools.bind(Tools.Bucket))
	erase_button.pressed.connect( PressedTools.bind(Tools.Eraser))

	# Color changed
	color_picker.color_changed.connect(
		func ColorChanged(new_color: Color):
			ColorMech.selected_color = new_color
	)

# Set up for "File Dialog"!
func InitiateFile():
	# menu
	menu_button.get_popup().index_pressed.connect(DropDownMenu)

	# file selected
	file_dialog.file_selected.connect(
		func HasSelected(path: String):
			FileMech.SaveFile(path, SharedVariables.color_cache)
			FileMech.OpenFile(path, CanvasMana.UpdateTexture)
			FileMech.ExportImage(path)

			is_draw_pixel = true
	)

	# if he didn't click (save)!
	file_dialog.canceled.connect(
		func AbleToDraw():
			is_draw_pixel = true
	)

# ------ Base Functions ------

func _ready() -> void:
	# Set the variables for the resource
	CanvasMana.grid_place = grid_place
	CanvasMana.sprite = sprite

	InitiateImage() # Set up image
	InitiateConnections() # Set up connections!
	InitiateFile() # Set up File Func

	ReceiveOpen() # Openning
	ReceiveLanguage() # Translator

func _input(event: InputEvent) -> void:
	# Check input
	if event.is_action_pressed('ui_use_tool') and is_draw_pixel:
		match what_tool:
			Tools.Draw:
				ColorMech.ColorPixel(what_pixel, color_picker)
			Tools.Bucket:
				ColorMech.ColorAllPixel(what_pixel, SharedVariables.tex, SharedVariables.image)
			Tools.Eraser:
				ColorMech.ErasePixel(what_pixel, SharedVariables.tex, SharedVariables.image)
	elif event.is_action_pressed('ui_open'):
		OpenColorPicker()
	elif event.is_action_pressed('ui_zoom_in'):
		ApplyZoom(1)
	elif event.is_action_pressed('ui_zoom_out'):
		ApplyZoom(-1)

	# Detect Mouse Motion
	if event is InputEventMouseMotion:
		SharedVariables.mouse_pos = draw_place.get_global_mouse_position()

func _process(_delta: float) -> void:
	# Setting the values
	what_pixel = PixelMech.point_on_pixel

	PixelsDetection() # Checking of the mouse and collisions
	CanvasMana.MovingCanvas(Layout) # Moving the frame it self
