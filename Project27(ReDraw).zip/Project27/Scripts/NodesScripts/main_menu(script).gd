extends CanvasLayer

@onready var main_menu: Control = $MainMenu
@onready var panel: PanelContainer = $MainMenu/Panel
@onready var make_button: Button = $MainMenu/Panel/HBox/VBoxElements/MakeButton
@onready var open_button: Button = $MainMenu/Panel/HBox/VBoxElements/OpenButton
@onready var select_window: Window = $MainMenu/SelectWindow
@onready var submit_button: Button = $MainMenu/SelectWindow/Panel/VPixels/SubmitButton
@onready var check_box: CheckBox = $MainMenu/Panel/HBox/VBoxElements/HBoxLanguage/CheckBox
# @onready var width_edit: SpinBox = $MainMenu/SelectWindow/Panel/VPixels/HWidth/WidthEdit
# @onready var height_edit: SpinBox = $MainMenu/SelectWindow/Panel/VPixels/HHeight/HeightEdit
@onready var label_doc: Label = $MainMenu/Panel/HBox/VBoxDocs/Label
@onready var size_label: Label = $MainMenu/SelectWindow/Panel/VPixels/HSize/SizeLabel
@onready var size_edit: SpinBox = $MainMenu/SelectWindow/Panel/VPixels/HSize/SizeEdit
@onready var file_dialog: FileDialog = $MainMenu/FileDialog

@export_group('Variables')
@export var packed_scene: PackedScene

func _ready() -> void:
	make_button.pressed.connect(MakePressed) # Connect (Make Sprite) button
	open_button.pressed.connect(OpenPressed) # Connect (Open Sprite) button
	check_box.toggled.connect(LanguagePressed) # Connect (Language) button

	select_window.close_requested.connect(HideWindow) # Close the window (Hides it)
	submit_button.pressed.connect(CreateSprite) # Real Creating

	file_dialog.filters = ['*.json ; JSON File'] # Filters
	file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE # Mode

	# Connect (Open Sprite), When pressing the button
	file_dialog.file_selected.connect(
		func HasSelected(path: String):
			SharedVariables.is_openning = true
			SharedVariables.file_path = path

			CreateSprite()
	)

# Just show the window
func MakePressed():
	select_window.popup_centered()

# Yeah...also shows a window
func OpenPressed():
	file_dialog.popup_centered()

# Language changer
func LanguagePressed(toggled: bool):
	SharedVariables.change_language = toggled
	ChangeLanguage(toggled)

# ....Hides it...
func HideWindow():
	select_window.hide()

# (Creating) sprite and (Changing) scene
func CreateSprite():
	SharedVariables.sprite_size = Vector2i(
		int(size_edit.value),
		int(size_edit.value)
	)
	SharedVariables.image = Image.create(
		SharedVariables.sprite_size.x,
		SharedVariables.sprite_size.y,
		true,
		Image.FORMAT_RGBA8
	)

	await get_tree().create_timer(0.25).timeout
	get_tree().change_scene_to_packed(packed_scene)

func ChangeLanguage(toggled: bool):
	if toggled:
		label_doc.text = 'مرحبا بك في "مشروع الرسم"
						هذا المشروع
						مفترض انه
						"يعلمك كيفية صنع تطبيق رسم بيكسل".

						التحكم:
						ض > للرسم
						ص > دلو
						ث > مسح
						مسافه > يفتح قائمة الألوان

						اتمنى لك الاستمتاع ❤️'
		make_button.text = 'جديد'
		open_button.text = 'فتح'
		size_label.text = 'حجم الصوره: '
		submit_button.text = 'اصنع'
		main_menu.layout_direction = Control.LAYOUT_DIRECTION_RTL

		file_dialog.cancel_button_text = 'اغلاق'
		file_dialog.ok_button_text = 'فتح'
	else:
		label_doc.text = 'Welcome to "Pixel Project"
						This porject
						should make you
						"learn how to make pixel app".

						controls:
						Q > Draw
						W > Bucket
						E > Earse
						Space > Opens Color Picker

						Hop you enjoy ❤️'
		make_button.text = 'New'
		open_button.text = 'Open'
		size_label.text = 'Sprite Size: '
		submit_button.text = 'Submit'
		main_menu.layout_direction = Control.LAYOUT_DIRECTION_LTR

		file_dialog.cancel_button_text = 'Cancel'
		file_dialog.ok_button_text = 'Open'
